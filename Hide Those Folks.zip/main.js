function remove() {
    document.querySelector("#BuddylistPagelet").style.display = "none";
    document.querySelector("#pagelet_sidebar").style.display = "none";
}

window.onload = remove;